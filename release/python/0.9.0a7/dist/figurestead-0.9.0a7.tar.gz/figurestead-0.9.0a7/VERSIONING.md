# Figurestead alpha version identities

## Unpublished preparation candidate: a7 / alpha.8

Candidate identities are Python `0.9.0a7`, browser `0.9.0-alpha.8` and future
coordinated tag `v0.9.0-alpha.8`, prepared from protected main `a702efa5376572fdecd6236abe588659e6b09c74`
after accepted PRs #67, #68, #69 and #70. PyPI, TestPyPI, npm and the GitHub
tag were checked read-only before preparation and were absent. They are not
published versions; availability must be rechecked immediately before any
separately authorized publication.

See [candidate notes](release/notes/0.9.0a7-web-alpha.8.md). Schema 0.4,
renderer API 1 and consumer dependency floors remain unchanged. npm publication
is intended for `alpha`; `latest` must remain unchanged. A producing commit binds
package inputs, and a later retaining commit binds the exact archives and ledgers.
Neither source version strings nor a successful local build establish publication.

## Current published release (2026-10-23 America/Chicago)

- Python: `figurestead` **0.9.0a6**.
- Browser: `@figurestead/web` **0.9.0-alpha.7**.
- Coordinated GitHub prerelease: [`v0.9.0-alpha.7`](https://github.com/CharlesMish/figurestead/releases/tag/v0.9.0-alpha.7).
- Release target: `7d5d959ad9c4387c445a6b34a8b67a18505ed477` (PR #65).
- npm `alpha` points to alpha.7; `latest` intentionally remains alpha.1.

The accepted exact wheel, sdist and npm tarball were published and verified on TestPyPI, PyPI, npm and GitHub without rebuilding. The [release record](https://github.com/CharlesMish/figurestead/releases/tag/v0.9.0-alpha.7), [retained artifact index](release/README.md) and [current onboarding](docs/getting-started.md) are the living publication authorities. Schema 0.4, renderer API 1, dependency floors and package counters are unchanged.

Changes newly shipped since a5/alpha.6 include the PR #60 interpolation/factual-description/category-tick corrections, PR #62 Python line performance and PR #63 matrix decoration containment. PR #61 reconciled living docs; PR #64 patched build/publisher tooling. Accepted original source ledgers and preparation notes retain their historical status.

## Historical a5 / alpha.6 release

Python `0.9.0a5` and browser `0.9.0-alpha.6` were published October 14, 2026 (America/Chicago) at `56faf759a282d428602d0c02027112f6a508e471` (PR #59). The [alpha.6 release](https://github.com/CharlesMish/figurestead/releases/tag/v0.9.0-alpha.6) records measured footers, transactional single-path exports, browser mark bands and scientific-meaning repairs. Its exact retained bytes, source bindings, and version-specific descriptions are unchanged; at its publication, npm `alpha` pointed to alpha.6.

## Historical a4 / alpha.5 release

Python `0.9.0a4` and browser `0.9.0-alpha.5` were published 2026-10-04 at
`889b8d15f364b4edbc71a9eec4ce572f73d705b5`. The
[release](https://github.com/CharlesMish/figurestead/releases/tag/v0.9.0-alpha.5)
contains SVG typography/subtitle, dense-array validation, DirectLabels lifecycle,
authored matrix-domain and minimum-dependency compatibility repairs.
At publication, npm `alpha` pointed to alpha.5 and `latest` remained alpha.1.
The [preparation notes](release/notes/0.9.0a4-web-alpha.5.md), review record,
package-embedded READMEs and a4/alpha.5 gallery retain their original context.

## Historical a3 / alpha.4 release

Python `0.9.0a3` and browser `0.9.0-alpha.4` were published 2026-09-29 UTC at
`9260af190e60c621244072675c238db4822b8632`.
Their [release](https://github.com/CharlesMish/figurestead/releases/tag/v0.9.0-alpha.4)
and retained artifacts remain available. Their features carry forward into later releases.

## Historical a2 / alpha.3 foundation

Python `0.9.0a2` and browser `0.9.0-alpha.3` remain published historical versions. Their coordinated [prerelease](https://github.com/CharlesMish/figurestead/releases/tag/v0.9.0-alpha.3) was published 2026-09-20 UTC. B2 S1–S3 identity, `series_slots`, baseline direct labels and the bounded reference-theme designation already shipped there. Python a1 and browser alpha.1/alpha.2 remain historical as well.

The public landing page retains version-bound a4/alpha.5 gallery examples and a2/alpha.3 specimens alongside an earlier-alpha archive. Their image bytes and manifests are historical authority, not a6/alpha.7 output. Website status updates and deployment are separate from package publication; use the current GitHub onboarding for install versions.

## Version and retention conventions

Python uses PEP 440; npm and Git prerelease tags use SemVer spelling. The package counters are independent. The coordinated tag names both versions; it does not force their suffixes to match. Private repository tooling stays at 0.0.0; schema and renderer API versions are unchanged.

Exact-version installs are reproducible; `@alpha` intentionally follows the prerelease channel. Retained artifacts and source-input ledgers are immutable. Verify them against their producing authority, not later repository prose. Any future preparation and publication requires separate review and authorization; it must not replace published bytes or move historical tags.
