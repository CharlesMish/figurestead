"""Open observation identities for the default line route (not scatter/poses)."""

import numpy as np
import matplotlib as mpl
from matplotlib.lines import Line2D
from matplotlib.markers import MarkerStyle
from matplotlib.legend_handler import HandlerBase
from matplotlib.transforms import IdentityTransform


# Point sizes, independently balanced rather than equal bounding boxes.
LINE_IDENTITIES = (("o", 6.0), ("s", 5.4), ("^", 7.0), ("D", 5.4))


def marker_indices(count, stride):
    """Authored observation indices; presentation density, never line sampling."""
    indices = list(range(0, count, stride))
    if count and indices[-1] != count - 1:
        indices.append(count - 1)
    return indices


def finite_runs(y):
    """Half-open authored-index intervals; singletons are retained."""
    changes = np.diff(np.r_[False, np.isfinite(y), False].astype(int))
    return list(zip(np.flatnonzero(changes == 1), np.flatnonzero(changes == -1)))


def line_marker_indices(y, stride):
    """Finite original cadence indices plus the boundaries of each real run."""
    if not np.isnan(y).any():
        return marker_indices(len(y), stride)
    selected = {i for i in range(0, len(y), stride) if np.isfinite(y[i])}
    for start, stop in finite_runs(y):
        selected.update((int(start), int(stop - 1)))
    return sorted(selected)


def visible_intervals(a, b, centers, marker, size, padding=0.):
    """Subtract the union of convex marker interiors from one display segment."""
    if np.ma.isMaskedArray(centers):
        # Matplotlib hides a marker when either offset coordinate is masked.
        # Only unmasked centers cut holes; unwrap those rows for NumPy 1.24
        # whose masked-vector dot product raises even with an all-false mask.
        centers = centers[~np.ma.getmaskarray(centers).any(axis=1)].data
    delta = b - a
    blocked = []
    for center in centers:
        p = (a - center) / size
        d = delta / size
        if marker == "o":
            aa, bb, cc = d @ d, 2 * (p @ d), p @ p - (.5 + padding / size) ** 2
            disc = bb * bb - 4 * aa * cc
            if aa == 0 or disc <= 0:
                continue
            lo, hi = (-bb - np.sqrt(disc)) / (2 * aa), (-bb + np.sqrt(disc)) / (2 * aa)
        else:
            shape = MarkerStyle(marker)
            vertices = shape.get_path().transformed(shape.get_transform()).vertices[:-1].tolist()
            lo, hi = 0., 1.
            for v, w in zip(vertices, vertices[1:] + vertices[:1]):
                edge = np.subtract(w, v)
                cross = lambda q: edge[0] * q[1] - edge[1] * q[0]
                value, rate = cross(p - v) + padding / size * np.linalg.norm(edge), cross(d)
                if rate == 0:
                    if value < 0:
                        hi = -1
                        break
                elif rate > 0:
                    lo = max(lo, -value / rate)
                else:
                    hi = min(hi, -value / rate)
        if max(0., lo) < min(1., hi):
            if lo <= 0 and hi >= 1:
                # One hole covers this entire segment. No later hole can
                # restore ink; dense/coincident observations need no union.
                return
            blocked.append((max(0., lo), min(1., hi)))
    cursor = 0.
    for lo, hi in sorted(blocked):
        if lo > cursor:
            yield cursor, lo
        cursor = max(cursor, hi)
    if cursor < 1:
        yield cursor, 1.


class _MarkerCandidates:
    """Draw-local broad phase in renderer coordinates, never observation indices.

    A padded convex glyph fits in a circle of radius R * (1 + padding / r),
    where R/r are its circumradius/inradius about the marker origin. Scaling
    by this factor moves *every* edge outward by at least padding. Thus the
    expanded segment box is a conservative superset, including nonadjacent
    crossings and the triangle/diamond miter corners. Exact hole geometry is
    still decided by visible_intervals. Storage is linear, not segment × marker.
    """

    def __init__(self, centers, marker, size, padding):
        if np.ma.isMaskedArray(centers):
            centers = centers[~np.ma.getmaskarray(centers).any(axis=1)].data
        centers = np.asarray(centers)
        centers = centers[np.isfinite(centers).all(axis=1)]
        self.centers = centers[np.argsort(centers[:, 0], kind="stable")]
        self.x = self.centers[:, 0]
        if marker == "o":
            radius = size / 2 + padding
        else:
            shape = MarkerStyle(marker)
            v = shape.get_path().transformed(shape.get_transform()).vertices[:-1]
            edge = np.roll(v, -1, axis=0) - v
            inradius = np.min(np.abs(edge[:, 0] * v[:, 1] - edge[:, 1] * v[:, 0])
                              / np.linalg.norm(edge, axis=1))
            radius = np.max(np.linalg.norm(v, axis=1)) * (size + padding / inradius)
        # Round outward; a boundary candidate must never be lost to rounding.
        self.radius = np.nextafter(radius, np.inf)

    def for_segment(self, a, b):
        low = np.nextafter(np.minimum(a, b) - self.radius, -np.inf)
        high = np.nextafter(np.maximum(a, b) + self.radius, np.inf)
        start, stop = np.searchsorted(self.x, [low[0], high[0]], side="left")
        candidates = self.centers[start:stop]
        return candidates[(candidates[:, 1] >= low[1]) & (candidates[:, 1] <= high[1])]


class IdentityLine(Line2D):
    """Retain scientific data; remove only this stroke below its own markers.

    Recompute in display coordinates on every draw, including resize/export.
    No background is painted; overlapping holes are unioned, not XORed.
    """

    def draw(self, renderer):
        points = getattr(self, "identity_points", None)
        if points is None or not points.get_visible() or points.get_alpha() == 0:
            return super().draw(renderer)
        centers = points.get_offset_transform().transform(points.get_offsets())
        size = renderer.points_to_pixels(np.sqrt(points.get_sizes()[0]))
        vertices = self.get_transform().transform(self.get_xydata())
        proxy = Line2D([], [])
        proxy.update_from(self)
        proxy.set_figure(self.get_figure())
        proxy.set_transform(IdentityTransform())
        # Clip endpoints meet marker outlines; projecting caps must not refill holes.
        proxy.set_solid_capstyle("butt")
        proxy.set_dash_capstyle("butt")
        travelled = 0.
        offset, dashes = self._unscaled_dash_pattern
        dash_scale = self.get_linewidth() if mpl.rcParams["lines.scale_dashes"] else 1.
        clearance = renderer.points_to_pixels(self.get_linewidth() + getattr(self, "identity_edge_width", 0.)) / 2
        candidates = _MarkerCandidates(centers, self.identity_marker, size, clearance)
        for a, b in zip(vertices, vertices[1:]):
            if not (np.isfinite(a).all() and np.isfinite(b).all()):
                # Missingness removes a connection. Unlike a marker hole, it
                # contributes no path distance and the next run starts afresh.
                travelled = 0.
                continue
            length = np.linalg.norm(b - a)
            # Conservative stroke clearance also excludes oblique/self-crossing strokes,
            # not just the mathematical centerline. Existing edge strokes count too.
            for lo, hi in visible_intervals(a, b, candidates.for_segment(a, b), self.identity_marker, size, clearance):
                ends = np.array([a + lo * (b - a), a + hi * (b - a)])
                proxy.set_data(ends[:, 0], ends[:, 1])
                if dashes is not None and dash_scale:
                    phase = (travelled + lo * length) / renderer.points_to_pixels(1) / dash_scale
                    proxy.set_linestyle((offset + phase, dashes))
                proxy.draw(renderer)
            travelled += length
        self.stale = False


class IdentityLegend(HandlerBase):
    """Use the body's current rhythm, color, edge treatment and marker size."""

    def create_artists(self, legend, orig, xd, yd, width, height, fontsize, trans):
        from matplotlib.collections import PathCollection
        points = orig.identity_points
        y, x = (height - yd) / 2, width / 2 - xd
        sample = IdentityLine([-xd, width - xd], [y, y])
        sample.update_from(orig)
        sample.set_transform(trans)
        sample.set_clip_on(False)
        marker = PathCollection(points.get_paths(), sizes=points.get_sizes(),
                                offsets=[(x, y)], offset_transform=trans,
                                facecolors="none", edgecolors=points.get_edgecolors(),
                                linewidths=points.get_linewidths(), alpha=1)
        marker.set_transform(IdentityTransform())
        marker.set_path_effects(points.get_path_effects())
        sample.identity_points = marker
        sample.identity_marker = orig.identity_marker
        sample.identity_edge_width = getattr(orig, "identity_edge_width", 0.)
        ydata = orig.get_ydata()
        if not any(stop - start >= 2 for start, stop in finite_runs(ydata)):
            return [marker]
        return [sample, marker]
