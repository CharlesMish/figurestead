# @figurestead/web experimental public alpha

Preparation candidate `0.9.0-alpha.7` (not yet published). Framework-free scientific figures for the browser,
with Canvas and standalone SVG output. Requires Node >=22.22.0;
repository/release tooling uses patched Node 24.22.1 with bundled npm 11.19.1.
The Node 22 consumer check uses 22.23.4 / npm 10.9.9; the public engine floor
remains >=22.22.0. Prefer a maintained, security-patched Node release.

The commands below target this version after publication. For current public
installation use `0.9.0-alpha.6`; for candidate review install the retained tarball.

```sh
npm install --save-exact @figurestead/web@0.9.0-alpha.7
npm ls @figurestead/web
```

The package root provides Figurestead's accepted core rendering and custom
renderer-registry APIs. The complete temporal extension is available from
`@figurestead/web/extensions/temporal`; it is intentionally not a root export.

This package ships first-party TypeScript declarations for the root and
temporal surfaces. Import contract, controller, option, state, error, theme,
and temporal types directly from those package entrypoints—no downstream
declaration shim or shadow schema is needed. TypeScript provides structural
guidance; runtime validation remains authoritative for semantic constraints
such as finite data, ordered domains, canonical colors, and matching
cardinalities.

Accessibility descriptions use the same effective axis labels as the visible
figure. Plot-relative annotation positions are identified as such, rather than
reported as data coordinates.

New in the alpha.7 candidate: Figurestead resolves categorical x-axis tick display once for Canvas and SVG.
Long labels may be rotated and abbreviated to preserve the plot and fit the
figure; accessible data tables and abbreviated SVG ticks retain the full label.
Live Canvas resolution uses the actual font metrics; standalone SVG resolution
uses deterministic fallback metrics, so the exact abbreviation can differ.
If even a compact tick cannot fit, resolution raises `FiguresteadConfigError`
with an insufficient-category-space message. Enlarge the host or shorten the
authored labels; a rejected `setConfig()` leaves the existing figure intact.
This does not change category values, their ordering, or numeric-axis labels.

The alpha.7 candidate also corrects opt-in monotone interpolation so each
interval stays within its endpoint bounds, including uneven x spacing and
direction changes. Authored data and the default interpolation policy remain
unchanged. Compact browser layouts still have bounded text/host capacity.

## First figure

Rendering requires a complete normalized figure contract. The repository's
[runnable browser first-success example](https://github.com/CharlesMish/figurestead/tree/7b9482a939da77bfc0d256682707ef03ee02332a/examples/browser-first-success)
remains useful for source development. An installed-package consumer can render
the same small scientific line without cloning the repository. In a new project
directory, install the package and the Vite version used by the
repository's consumer checks:

```sh
npm init -y
npm install --save-exact @figurestead/web@0.9.0-alpha.7
npm install --save-dev --save-exact vite@8.2.4
```

Save these two files in that directory:

<!-- figurestead-npm-first-success:index.html -->
```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Figurestead first success</title>
    <style>
      body { margin: 24px; background: #f1eee5; }
      canvas { display: block; width: min(100%, 760px); height: auto; background: #fffdfa; }
    </style>
  </head>
  <body>
    <canvas id="figure" width="760" height="520" aria-label="Three-point Figurestead line example"></canvas>
    <script type="module" src="./main.js"></script>
  </body>
</html>
```

<!-- figurestead-npm-first-success:main.js -->
```js
import {
  createFigurestead,
  resolveTheme,
  validateThemePack,
} from "@figurestead/web";
import slipwarePack from "@figurestead/web/themes/slipware" with { type: "json" };

const theme = resolveTheme(validateThemePack(slipwarePack), "slipware");
const contract = {
  schemaVersion: "0.4",
  rendererApiVersion: "1",
  theme,
  profile: { key: "first_success", name: "First success", marker: "ring_core", markerSize: 42, markerAlpha: 0.84, edgeWidth: 1.05, coreFraction: 0.12, pointGlow: false, gridX: true, gridY: true, gridAlpha: 0.4, summaryGlow: false },
  timeline: { rainIn: [0, 0], marksEnter: [0, 1], summaryCompiles: [0.8, 1], rainOut: [0, 0], settle: [0.9, 1] },
  motion: { frames: 1, fps: 1, rainStreams: 0, rainGlyphs: 0, lightingPeak: 0, trailAlpha: 0, seed: 1, durationMs: 1 },
  style: { glyphs: ["ring", "square", "triangle", "diamond"], series: {} },
  spec: { title: "Figurestead first success", subtitle: "One deterministic normalized line contract", xLabel: "observation", yLabel: "response", signature: "figurestead · first success", description: "One line with three observations." },
  layout: { type: "grid", columns: 1, gap: 18, sharedX: false, sharedY: false },
  view: { profile: "atlas", motion: "none", ambient: "none", strategy: "none" },
  panels: [{ id: "line", renderer: "line", spec: { title: "Figurestead first success", xLabel: "observation", yLabel: "response", description: "One line with three observations." }, xScale: { type: "linear" }, yScale: { type: "linear" }, annotations: [], encoding: { interpolation: "linear" }, presentation: { panelSurface: true, frame: true, legend: "none", lineWidth: 2, markerScale: 1 }, data: { x: [0, 1, 2], revealOrder: "x", series: [{ key: "series-1", label: "Series 1", y: [0, 1, 0] }] } }],
};

const canvas = document.querySelector("#figure");
const figure = createFigurestead(canvas, contract, { autoplay: false, reducedMotion: true });
figure.resize();
document.documentElement.dataset.figuresteadReady = "true";
```

Start the local server with `npx vite --host 127.0.0.1` and open the local URL
it prints. The page should show a three-point synthetic line rising from 0 to
1 and returning to 0. Keep the generated `package-lock.json` to record the
consumer environment. This route resolves installed package imports through
Vite; opening `index.html` directly is not sufficient.

This package also ships six curated theme subpaths generated byte-for-byte from
Figurestead's canonical theme JSON rather than retyped as JavaScript constants.
For example, in Node or TypeScript:

```ts
import {
  applyTheme,
  resolveTheme,
  type FiguresteadContract,
} from "@figurestead/web";
import slipwarePack from "@figurestead/web/themes/slipware" with { type: "json" };

export function withSlipware(contract: FiguresteadContract): FiguresteadContract {
  return applyTheme(contract, resolveTheme(slipwarePack, "slipware"));
}
```

The same explicit subpath works through the tested Vite browser route. Other
curated subpaths are `registration-ink`, `ultraviolet-laboratory`,
`lavender-fog-notebook`, `midnight-transit-signal-slate`, and
`deep-observatory-sage-core` under `@figurestead/web/themes/`.

See the [theme selection guide](https://github.com/CharlesMish/figurestead/blob/7b9482a939da77bfc0d256682707ef03ee02332a/docs/theme-selection.md) for Python keys, browser paths and version-specific limits.

The declarations and all six curated-theme subpaths above are included in
`@figurestead/web@0.9.0-alpha.7`.

Python and browser surfaces share normalized contract vocabulary and selected
theme definitions. Shared semantics do not imply pixel-identical output or
identical renderer coverage. In particular, the populated categorical matrix
is currently Python-rendered; this package does not claim a browser categorical
matrix renderer.

## Line identity and direct labels

Default line series combine color with persistent open **circle (S1), square (S2), and upright triangle (S3)** markers and matching line-and-marker legends. Line rhythm remains an independent semantic channel. `setData` retains established keyed identity through supported filtering/reordering and partial style overrides. `setConfig` replaces the contract.

Lavender Fog Notebook is the reference light theme; Ultraviolet Laboratory is the reference dark theme for the [bounded three-series line profile](https://github.com/CharlesMish/figurestead/blob/7b9482a939da77bfc0d256682707ef03ee02332a/docs/reference-themes.md), not universal accessibility, CVD or print qualification. Default theme selections are unchanged.

Opt in with `style: { ...contract.style, directLabels: true }` (`style.directLabels: true`). Direct labels reuse the actual body marker identity beside the traces. V1 covers ordinary one-panel, 2–3-series line figures with single-line printable ASCII labels. Unsupported or insufficient layouts fall back atomically to the ordinary legend. This treatment does not support Unicode, multiline or math interpretation; printable ASCII math punctuation is literal. Active browser transitions use ordinary treatment until settled, and exports without trustworthy measurement retain the ordinary legend.

See the [ordinary/direct-label example](https://github.com/CharlesMish/figurestead/tree/7b9482a939da77bfc0d256682707ef03ee02332a/examples/direct-series-labels) and [detailed direct-label contract](https://github.com/CharlesMish/figurestead/blob/7b9482a939da77bfc0d256682707ef03ee02332a/docs/direct-series-labels.md). The [explicit rendered-series contrast audit](https://github.com/CharlesMish/figurestead/blob/7b9482a939da77bfc0d256682707ef03ee02332a/docs/rendered-series-contrast.md) measures caller-specified rendering facts separately from the static palette audit.

## Features carried forward from alpha.4

Opt-in `style.markerStride` controls marker display by authored observation index, always including endpoints; it does not reduce data or the continuous line. When a participating body line is non-solid, every direct-label row adds its actual line sample before marker and text; extra width can trigger whole-legend fallback. Unconfigured lines remain solid at every series count; explicit `lineStyles` and keyed rhythm remain supported.

`setData` now reserves first-encounter ranks for removed keys and assigns newcomers new ranks. `setConfig` still replaces/reset the contract. Empty strip groups retain categories without invented medians; point-only lines have marker-only legends; collision-safe IDs keep export resources associated with their own marks. Continuous authored rhythm survives segment subdivision and marker holes.

See the [release notes](https://github.com/CharlesMish/figurestead/blob/7b9482a939da77bfc0d256682707ef03ee02332a/release/notes/0.9.0a3-web-alpha.4.md) and [line semantics](https://github.com/CharlesMish/figurestead/blob/7b9482a939da77bfc0d256682707ef03ee02332a/docs/line-series-semantics.md). Browser y missingness remains unsupported. These additions do not expand the bounded reference designation or direct-label profile.

## Controller failures

New in the alpha.7 candidate: Figurestead generates compact factual descriptions for core line, scatter,
and strip-summary figures from their prepared observations and summaries.
Authored narrative remains separate context, including after `setData`; raw
tables retain full values. See [factual descriptions](https://github.com/CharlesMish/figurestead/blob/7b9482a939da77bfc0d256682707ef03ee02332a/docs/factual-descriptions.md)
for the supported facts, precision policy, and source-note channels.

`setConfig(next)` is transactional: a validation, compilation, renderer
preparation, scene-resolution, composition, or accessibility-description error
leaves the last accepted contract, scenes, pixels, companion, and motion state
active. The original configuration error is thrown to the caller.

Hosts may observe asynchronous renderer failures with the existing creation
options pattern:

```js
const figure = createFigurestead(canvas, contract, {
  onError(error, context) {
    // context.phase is "draw" or "height-negotiation".
    // error is the original renderer or host-callback error object.
  },
});
```

After a draw failure the controller is stopped, reports `playing: false` and
`runtimeFailed: true`, and will not redraw through play, replay, resize, or
reduced-motion changes. A later valid `setConfig()` clears that state and
renders normally. Lifecycle notifications remain on `onState`; runtime failures
are reported only through `onError`.

## Responsive headers and host-owned height

At compact live-Canvas widths, Figurestead preserves the established plot
geometry and uses a bounded two-line title plus a one-line ellipsized subtitle
when the host does not opt in to more height. Complete strings remain in the
associated accessibility companion. Figurestead never changes host CSS by
default.

An auto-height host may opt in with one mount-scoped adapter. Figurestead's
current measurement convention is the CSS-pixel border box reported by
`canvas.getBoundingClientRect()` (including any reflected CSS transform). Retain
the baseline independently in that same measurement space; do not derive it
from the canvas after applying an earlier request:

```js
const baselineHeight = 196;
const figure = createFigurestead(canvas, contract, {
  heightNegotiation: {
    getBaselineHeight() { return baselineHeight; },
    requestPreferredHeight({ preferredHeight, signal }) {
      if (!signal.aborted) canvas.style.height = `${preferredHeight}px`;
    },
  },
});
```

State-driven or delayed hosts may apply on a later frame. The return value is
not an acknowledgement; the host applies the absolute height and Figurestead's
existing resize observation resolves the granted layout:

```js
requestPreferredHeight({ preferredHeight, signal }) {
  requestAnimationFrame(() => {
    if (!signal.aborted) canvas.style.height = `${preferredHeight}px`;
  });
}
```

Accepted contract, width, baseline, remount, and destroy transitions abort the
prior signal. A host may decline or clamp a request; the fixed-height fallback
then remains active without automatic retry in that generation. Host-applied
CSS remains host state after `destroy()`. Before remount, the host either keeps
that height intentionally or restores its independent baseline source; residual
preferred height is never inferred as the next baseline by Figurestead.
Height negotiation applies only to live Canvas rendering. SVG, paper, and
explicitly dimensioned exports retain their requested dimensions.

## Rendered series contrast

`contrastAudit(theme)` remains a static authored-palette inspection.
`renderedSeriesAudit(theme, { substrate, opacity, compositing: "srgb-source-over" })`
measures the supplied theme's series colors in the caller-supplied single-layer
context. The opaque `#RRGGBB` substrate and opacity in [0,1] are required; no
renderer/surface defaults are inferred. Results retain unrounded effective sRGB
channels and ratio. The exact policy is `passes = ratio >= 3`, without an epsilon
or display-rounding rule. Values effectively on the floating-point threshold may
classify differently across Python/JavaScript final ULPs; this is not physical
certification. Figures and colors are never changed.

Nonempty **theme-level** `seriesEdges` are conservatively rejected. Per-series
contract/style overrides can independently change the rendered color or add an
edge; they are not inspected by that theme-level check. The caller must account
for those overrides before interpreting the result as a rendered-mark measurement.

Verified Canvas line **segments** use panel or field with effective .78 (Firefox
exposes its float32 value); SVG line **segments** use panel or field at 1. Python's
verified default line **polyline** uses field/.88. Companion markers/points may
have different opacity and are outside those contexts. This is not an assessment
of glow, antialias boundaries, every layered mark or whole-figure accessibility.

### Additional line series

The bounded persistent-identity reference profile covers the first three ordinary
line series. Additional series retain deterministic ring/square/triangle/diamond
marker cycling and theme colors without a distinguishability claim. Unconfigured
lines remain solid at every series count; non-solid rhythm must be authored.
Missing `style.lineStyles` normalizes to `["solid"]`; explicitly supplied arrays
retain their existing glyph-block allocation, and per-key `lineStyle` wins.
See the [line semantics](https://github.com/CharlesMish/figurestead/blob/7b9482a939da77bfc0d256682707ef03ee02332a/docs/line-series-semantics.md).
This behavior begins with alpha.4; it is not retroactively part of alpha.3.

## Scene-mark repairs in alpha.6

Alpha.6 repairs missing Canvas reference/row bands, exposes a
closed `Mark` union and `MARK_KINDS`, and rejects unknown scene kinds instead of
silently omitting them. Custom renderer drawing remains supported; opaque custom
evidence is reported as incomplete coverage. See the [mark and coverage
contract](https://github.com/CharlesMish/figurestead/blob/7b9482a939da77bfc0d256682707ef03ee02332a/docs/browser-scene-marks.md).
These repairs begin with alpha.6; alpha.5 does not include them.

Package version 0.9.0-alpha.7. [Source and full project documentation](https://github.com/CharlesMish/figurestead).
